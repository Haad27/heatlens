# HeatLens — Urban Heat Intelligence for US cities

HeatLens is a planning-grade urban heat platform for the United States. Pick a location on the satellite map and it returns **short-form answers**: where it is hot, why, who is affected, and what to do — as cards and badges, not paragraphs.

It is built for city sustainability offices, real estate developers and public health agencies. Every number is labelled with where it came from.

---

## Getting started

```bash
git clone <this-repo>
cd fortyguard          # or whatever you named the checkout
npm install
cp .env.local.example .env.local
# Fill in any keys you have. Leaving them blank is fine — the app runs on
# clearly labelled demo data.
npm run dev
```

Open [http://localhost:3000](http://localhost:3000). Search or click the satellite map, then **Proceed with Location**. Phoenix, Houston, Fresno and Newark are good starting points.

### What you will see without any keys

- A **Demo data** badge in the header.
- A realistic, deterministic urban heat field (not random noise) with clustered hotspots, contributing-factor breakdowns, vulnerability context, ranked recommendations and a PDF report.
- Live USGS land-cover sampling, live NASA POWER climate trend, and live address search — those sources are keyless.

Add `FORTYGUARD_API_KEY` to switch the temperature layer from simulated to measured. Add `CENSUS_API_KEY` to switch population vulnerability from placeholder to ACS. Add `GEMINI_API_KEY` if you want the PDF executive summary phrased by Gemini rather than the rule-based template.

---

## Credentials

For every credential the product can use: what it is, where to get it, which free tier applies, which variable to paste it into, and what happens if it is missing. The app **always boots**. Missing keys degrade a specific layer and label it; they never fabricate an unlabelled number.

### `FORTYGUARD_API_KEY` — required for live temperature

**What it is.** FortyGuard's Temperature API: 2-metre air temperature at 60–100 m resolution, covering historical (2019–present; this product exposes 2021–present), near-real-time, and a 12-hour forecast. Also the `exceedance` (hours above a threshold) and `persistence` (longest unbroken run above a threshold) analytic layers.

**Where to sign up.** [fortyguard.com/hackathon26](https://fortyguard.com/hackathon26) for the Hackathon'26 programme, or [dashboard.fortyguard.com](https://dashboard.fortyguard.com) for a trial / API key from the developer dashboard.

**Free tier.** Hackathon'26 credits, or a trial allocation from the dashboard. The API Basic plan includes heatmaps up to 10 mi². Credits are deducted only when a job completes successfully.

**Where to paste it.** `.env.local` as `FORTYGUARD_API_KEY=...`. On Vercel, Project → Settings → Environment Variables.

**If it is missing.** `src/lib/fortyguard/client.ts` uses the deterministic simulator in `src/lib/fortyguard/mock.ts`. The UI shows a **Demo data** badge and every temperature figure is provenance-labelled. Set `FORTYGUARD_MOCK_MODE=true` to keep using the simulator even when a key is present (useful for UI work so you do not spend credits).

### `CENSUS_API_KEY` — required for live population vulnerability

**What it is.** US Census Bureau American Community Survey 5-year estimates. Powers the Heat Vulnerability Score: population density, % aged 65+, % below poverty, % of households without a vehicle.

**Where to sign up.** [api.census.gov/data/key_signup.html](https://api.census.gov/data/key_signup.html) — instant, free, self-serve. A key is required; keyless ACS requests now return a "Missing Key" page.

**Free tier.** Unlimited for reasonable public use.

**Where to paste it.** `.env.local` as `CENSUS_API_KEY=...`.

**If it is missing.** With `DEMO_MODE` on (the default), the vulnerability panel shows clearly labelled placeholder demographics. With `DEMO_MODE=false`, the panel renders as unavailable and vulnerability is dropped from the severity weighting rather than scored as zero.

### Tree Equity Score API — not currently public

American Forests' Tree Equity Score does **not** currently expose a self-serve public API (`api.treeequityscore.org` returns 403 to unauthenticated callers, and there is no key signup). HeatLens therefore samples **USGS NLCD 2021 tree canopy cover** via the MRLC WMS GetFeatureInfo service, which is free, keyless and nationally consistent — the same underlying quantity TES is built on.

If you obtain TES access later, drop a client into `src/lib/datasources/` following the same `Provenance` contract as `landcover.ts` and swap it in `src/lib/analysis/pipeline.ts`. No other module needs to change.

### `GEMINI_API_KEY` — optional, phrasing only

**What it is.** Gemini is used **only** to turn already-computed findings into the PDF executive-summary prose. The prompt forbids inventing numbers, and the response is discarded on any failure.

**Where to sign up.** [aistudio.google.com](https://aistudio.google.com) — free tier, no credit card required.

**Free / trial.** Free-tier Flash (`gemini-2.5-flash` by default). Override the model with `GEMINI_MODEL`.

**Where to paste it.** `.env.local` as `GEMINI_API_KEY=...`.

**If it is missing.** `src/lib/generateInsights.ts` uses a deterministic template. The product is fully functional; the summary is labelled "Rule-based" rather than "AI-phrased". If Gemini is set but the call fails or times out, the same template is used — PDF generation never breaks.

### `ANTHROPIC_API_KEY` — optional third provider

**What it is.** Claude, used only if Gemini is unset or the Gemini call fails. Same phrasing-only contract as Gemini.

**Where to sign up.** [console.anthropic.com](https://console.anthropic.com).

**Free / trial.** Pay-as-you-go; a typical analysis costs a fraction of a cent. Override the model with `ANTHROPIC_MODEL` (default `claude-sonnet-4-5`).

**Where to paste it.** `.env.local` as `ANTHROPIC_API_KEY=...`.

**If it is missing.** Ignored. Fallback is Gemini (if configured) then the deterministic template.

### Database / KV connection — optional, recommended in production

FortyGuard bills per completed task, so caching is a cost control. HeatLens talks to [Vercel KV](https://vercel.com/docs/storage/vercel-kv) / [Upstash Redis](https://upstash.com/docs/redis/overall/getstarted) over REST (no native client, so it stays serverless-safe):

1. In the Vercel dashboard: Storage → Create Database → KV (or Redis).
2. Link it to the project. Vercel injects `KV_REST_API_URL` and `KV_REST_API_TOKEN`.
3. For local development, copy those values into `.env.local`, **or** use Upstash's own `UPSTASH_REDIS_REST_URL` / `UPSTASH_REDIS_REST_TOKEN`. Either pair works.

**If it is missing.** Locally, a `.cache/` directory plus an in-memory LRU. On Vercel without KV, an in-memory cache per serverless instance — repeat queries in the same instance are free, but a different instance will re-call FortyGuard. Link KV before you run this against live credits.

---

## Deploying to Vercel

1. Push this repository to GitHub.
2. In [vercel.com/new](https://vercel.com/new), import the repo. The framework is detected as Next.js; no build-command changes are needed.
3. Add environment variables under **Project → Settings → Environment Variables**, at least:
   - `FORTYGUARD_API_KEY` (live temperature)
   - `CENSUS_API_KEY` (live vulnerability)
   - `GEMINI_API_KEY` (optional — PDF executive summary phrasing; free tier at aistudio.google.com)
   - `ANTHROPIC_API_KEY` (optional third provider, used only if Gemini is unset or fails)
   - `DEMO_MODE=false` for a production deployment, so missing keys render as unavailable rather than as placeholders
   - `KV_REST_API_URL` / `KV_REST_API_TOKEN` if you linked a KV store (usually injected automatically)
4. Deploy. The first request to `/api/analysis` is a serverless function; on the Hobby plan Vercel caps it at 60 seconds, which is enough for a typical 1.2 km / 100 m analysis. Larger areas at 60 m can run longer — use a Pro plan, or drop granularity to 100 m, if you hit the cap.
5. Confirm `/api/status` reports `temperature.mode: "live"` after the key is set.

Hobby-plan notes:

- Heatmaps are capped at ~9.5 mi² by the product (FortyGuard Basic is 10 mi²). The default 1.2 km radius is ~2.2 mi².
- There is no separate backend. Everything is Next.js Route Handlers under `src/app/api/`.

---

## Data sources and methodology

Credibility with a client depends on being able to explain every figure. These are all of them.

| Source | Supplies | Why this one |
| --- | --- | --- |
| **FortyGuard Temperature API** | 2 m air temperature at 60–100 m; hours above a heat-risk threshold; longest continuous run above it; hourly heat index / apparent temperature / humidity | The only layer that resolves heat at the scale a city block is planned at. Historical from 2021, near-real-time, and 12-hour forecast. |
| **US Census Bureau Geocoder** | Address → coordinates; census tract for any point | Authoritative for US street addresses, free, no key, and returns the tract in the same call. Place names fall through to Nominatim, restricted to `countrycodes=us`. |
| **US Census Bureau ACS 5-year** | Population, % 65+, poverty rate, vehicle access, density, median income | Published for every tract, including small ones the 1-year sample suppresses. |
| **USGS NLCD 2021 (MRLC)** | Tree canopy %, impervious surface %, development intensity | Reference US land-cover dataset, keyless, nationally consistent. Used because Tree Equity Score has no public API. |
| **NASA POWER (MERRA-2)** | Warm-season daily maximum since 2021 | Regional trajectory without spending FortyGuard credits on years of daily history. ~50 km resolution — deliberately kept visually separate from the block-level figures. |
| **Esri World Imagery + OpenStreetMap** | Satellite basemap, optional streets, place search | Satellite is the default so rooftops, canopy and paving are visible under the heatmap. |

### How a hotspot is defined

A measurement cell is flagged when it exceeds **the area's own mean** by at least one standard deviation. Flagged cells are flood-filled into contiguous clusters; clusters smaller than three cells are discarded as noise. If a single cluster would swallow most of the area (a downtown that is uniformly hot), the threshold is raised until the remaining clusters are plausible intervention units. Detection is relative to the surrounding area, not to a fixed temperature, so it behaves the same way in Phoenix in July and in Seattle in April. Absolute public-health thresholds (NWS caution / extreme caution / danger) are applied separately, in the severity score.

### How severity is scored

Four terms, each normalised 0–1 then weighted:

1. **Thermal intensity** — z-score against the area baseline.
2. **Exposure duration** — hours above the heat-risk threshold, as a share of the analysed window.
3. **Absolute heat** — peak temperature against NWS heat bands.
4. **Population vulnerability** — ACS-derived Heat Vulnerability Score.

Any term without data is dropped and the remaining weights are renormalised, rather than scored as zero. The breakdown is shown on every hotspot.

### How contributing factors are attributed

NLCD canopy, impervious surface and medium/high-intensity development are sampled at five points across each hotspot footprint. Each is scored as a *deficit* against a reference (40% canopy target; 100% sealed / built as worst case) and weighted 0.40 / 0.35 / 0.25. The shares are the modelled surface contribution, not an inference from the temperature field — two equally hot blocks can have completely different causes, which is the point.

### How recommendations are produced

A deterministic rules engine in `src/lib/analysis/recommendations.ts`, keyed on the measured factors, exposure duration and vulnerability of each hotspot. Each rule records the values that triggered it. Expected cooling ranges are **near-surface air** temperature reductions from urban-heat-island field studies, not surface-temperature reductions (which are far larger and routinely misquoted). Cost bands are ranges, not point estimates.

A language model, when configured, is given those finished findings as fixed input and asked only to phrase them. It is never asked for a number. Without a key, a template produces the same structure from the same inputs.

### US-only, by design

FortyGuard coverage, the Census APIs and NLCD are all United States products in this release. International coordinates are rejected up front with a clear error rather than a downstream 400.

---

## Using the product

The interface is built for scanning, not reading. Charts and long executive copy are kept off the main path.

1. **Select a location.** Search or click the satellite map. Confirm lat/lng, then **Proceed with Location**.
2. **Read the results.** Two metric cards (vegetation coverage, building density), a satellite heatmap, and a ranked list of AI recommendations with cost, timeline and °C reduction.
3. **Open Detailed Analysis.** Three tabs, each a stack of short cards:
   - **Hotspot Analysis** — hot-spot / cool-spot counts, heat-island severity, a small 12-hour forecast sparkline (when available), named hot zones (`Cause: …`) and cool zones (`Source: …`).
   - **Vegetation Insights** — one-line canopy summary, tree coverage, parks, vegetation gaps, green opportunities (green roof, street trees, pocket park).
   - **Urban Correlations** — heat-source tags, building density/materials, one-sentence hotspot correlations, infrastructure impact.
4. **Download Report.** Same figures as the screen, as a printable / PDF brief.

The heatmap sits on Esri World Imagery. Legend: High Heat Areas, Cooling Zones, Cool Zones. The colour ramp is ColorBrewer RdYlBu reversed (blue → yellow → red), stretched to **this area's own range**.

Cool zones are the inverse of hotspots: cells significantly *below* the area mean, clustered the same way, then labelled from NLCD (water, park, light vegetation).

---

## Project structure

```
src/
  app/                  # App Router pages and Route Handlers
    api/analysis/       # POST a full analysis; GET one by id for the report
    api/forecast/       # one hour of the 12-hour forecast, fetched lazily
    api/geocode/        # Census Geocoder + Nominatim
    api/status/         # which credentials are present (never their values)
  components/
    landing/            # satellite location picker
    dashboard/          # results workspace
    results/            # short-form cards + Hotspot / Vegetation / Correlations tabs
    map/                # Leaflet satellite + canvas heat layer
    report/             # printable / PDF brief
    charts/             # kept for the PDF report only
  lib/
    fortyguard/         # submit → poll → normalise, plus the mock simulator
    datasources/        # Census, NLCD, NASA POWER, geocoder
    analysis/           # hotspots, cool zones, brief cards, factors, pipeline
    generateInsights.ts # Gemini phrasing (Claude optional) with a template fallback (report)
    report/             # static map compositor + jsPDF
    cache/              # KV / memory / filesystem
```

---

## FortyGuard API notes (live docs vs. the original brief)

Verified against [docs-api.fortyguard.com](https://docs-api.fortyguard.com) at build time. Discrepancies against the original project brief, recorded because the live docs are the source of truth:

1. `polygon_aoi` must be a GeoJSON **FeatureCollection** wrapping a Polygon feature. A bare `{ "type": "Polygon", ... }` is rejected with 400.
2. The API history window starts at **2019-01-01**, not 2021-01-01. This product intentionally exposes 2021 onward.
3. The Create Heatmap page documents `filter_type: 4` (range of days) while Known Limitations states filter types 1–3 only. We only use 1–3, and cap type 2 at the documented 23-hour maximum.
4. The shared status endpoint is `GET /v1/status/{activity_id}`.
5. Analytic layers `tcm` (snapshot, °C), `exceedance` (hours above threshold), `persistence` (longest run), and `time_of_measure` (hour of peak) are all available on the same `/v1/heatmap` endpoint via `analytic_type`.
6. Forecasts are the same endpoint with a `date_time` up to 12 hours ahead of now — there is no separate forecast route.
7. Environmental Parameters is `POST /v1/env_params` (not a heatmap mode). The API Basic plan allows three parameters per request; we request heat index, apparent temperature and relative humidity.
8. Regional coverage on current plans is **United States only**.

Polling is every 2.5 seconds with a ~105 s timeout, matching the docs' "bounded polling" guidance. Credits are only deducted on `Completed`.

---

## Scripts

| Command | What it does |
| --- | --- |
| `npm run dev` | Next.js dev server at localhost:3000 |
| `npm run build` | Production build |
| `npm run start` | Serve the production build |
| `npm run lint` | ESLint |

---

## Licence

Application code in this repository is available for the FortyGuard Hackathon'26 programme. Temperature data remains © FortyGuard. Census data is public-domain US government work. NLCD © USGS. NASA POWER © NASA. Map tiles © OpenStreetMap contributors and CARTO.
