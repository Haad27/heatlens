import type { BoundingBox, HeatGrid, HeatTile, LatLng } from "@/lib/types";
import { ringBox } from "@/lib/geo";

/**
 * Hotspot detection.
 *
 * The point of this module is that a hotspot is a *statistical* claim, not a
 * colour. A tile is only flagged when it is significantly hotter than the
 * surrounding area's own baseline, and isolated flagged tiles are discarded —
 * a single anomalous cell is sensor noise or a rooftop, not a heat island that
 * a city can act on. What survives is a contiguous cluster, which is what a
 * tree-planting or cool-roof programme is actually scoped around.
 *
 * Detection is relative to the AOI rather than to a fixed temperature so the
 * result stays meaningful in Phoenix in July and in Seattle in April. Absolute
 * public-health thresholds are applied separately, in the severity score.
 */

/**
 * Candidate thresholds, in standard deviations above the AOI mean.
 *
 * Detection walks this ladder rather than fixing on one value. In a downtown
 * core almost every cell clears +1σ, and a single flood fill then merges the
 * whole business district into one 70-hectare "hotspot" — technically correct
 * and operationally useless, because nobody scopes a tree-planting programme
 * around a quarter of a city. Raising the threshold until the largest cluster
 * is a plausible intervention unit separates the distinct thermal cores inside
 * that district. The threshold that was actually used is reported back so the
 * UI can state it.
 */
const Z_LADDER = [1.0, 1.3, 1.6, 1.9, 2.2] as const;
/** Relaxed threshold used when even the lowest rung finds nothing. */
const FALLBACK_Z = 0.65;
/** Largest share of the AOI a single cluster may occupy before the threshold is raised. */
const MAX_CLUSTER_SHARE = 0.08;
/** Discard clusters smaller than this — they are noise, not places. */
const MIN_CLUSTER_TILES = 3;
/** Below this spread the AOI is thermally uniform and has no real hotspots. */
const MIN_MEANINGFUL_STDDEV_C = 0.25;

export interface DetectedCluster {
  tiles: HeatTile[];
  center: LatLng;
  bbox: BoundingBox;
  polygon: [number, number][][];
  meanValue: number;
  peakValue: number;
  anomaly: number;
  zScore: number;
  areaSqMeters: number;
}

interface CellGeometry {
  cellWidthDeg: number;
  cellHeightDeg: number;
}

function estimateCellGeometry(tiles: HeatTile[]): CellGeometry {
  const widths: number[] = [];
  const heights: number[] = [];

  for (const tile of tiles.slice(0, 200)) {
    if (tile.ring.length < 4) continue;
    const box = ringBox(tile.ring);
    const w = box.east - box.west;
    const h = box.north - box.south;
    if (w > 0) widths.push(w);
    if (h > 0) heights.push(h);
  }

  const median = (values: number[]): number => {
    if (!values.length) return 0;
    const sorted = [...values].sort((a, b) => a - b);
    return sorted[Math.floor(sorted.length / 2)];
  };

  let cellWidthDeg = median(widths);
  let cellHeightDeg = median(heights);

  // Point-geometry fallback: infer spacing from the closest distinct centroids.
  if (cellWidthDeg <= 0 || cellHeightDeg <= 0) {
    const lngs = [...new Set(tiles.map((t) => Number(t.center.lng.toFixed(6))))].sort((a, b) => a - b);
    const lats = [...new Set(tiles.map((t) => Number(t.center.lat.toFixed(6))))].sort((a, b) => a - b);
    const gaps = (values: number[]) =>
      values.slice(1).map((v, i) => v - values[i]).filter((g) => g > 1e-7);
    cellWidthDeg = cellWidthDeg > 0 ? cellWidthDeg : median(gaps(lngs)) || 0.001;
    cellHeightDeg = cellHeightDeg > 0 ? cellHeightDeg : median(gaps(lats)) || 0.001;
  }

  return { cellWidthDeg, cellHeightDeg };
}

function tileAreaSqMeters(tile: HeatTile): number {
  if (tile.ring.length < 4) return 0;
  const box = ringBox(tile.ring);
  const midLat = (box.north + box.south) / 2;
  const metersPerDegLat = 111_320;
  const metersPerDegLng = 111_320 * Math.cos((midLat * Math.PI) / 180);
  return (box.north - box.south) * metersPerDegLat * (box.east - box.west) * metersPerDegLng;
}

/**
 * Group flagged tiles into contiguous clusters.
 *
 * Tiles are snapped onto an integer lattice derived from the cell size, then
 * flood-filled through the 8-neighbourhood. This is O(n) and, unlike a distance
 * threshold, is not fooled by the slight longitude-spacing drift across an AOI.
 */
function clusterTiles(
  flagged: HeatTile[],
  geometry: CellGeometry,
): HeatTile[][] {
  if (!flagged.length) return [];

  const originLng = Math.min(...flagged.map((t) => t.center.lng));
  const originLat = Math.min(...flagged.map((t) => t.center.lat));

  const lattice = new Map<string, HeatTile[]>();
  const coordsFor = (tile: HeatTile) => {
    const col = Math.round((tile.center.lng - originLng) / geometry.cellWidthDeg);
    const row = Math.round((tile.center.lat - originLat) / geometry.cellHeightDeg);
    return { col, row, key: `${col},${row}` };
  };

  for (const tile of flagged) {
    const { key } = coordsFor(tile);
    const bucket = lattice.get(key);
    if (bucket) bucket.push(tile);
    else lattice.set(key, [tile]);
  }

  const visited = new Set<string>();
  const clusters: HeatTile[][] = [];

  for (const startKey of lattice.keys()) {
    if (visited.has(startKey)) continue;
    visited.add(startKey);

    const cluster: HeatTile[] = [];
    const queue = [startKey];

    while (queue.length) {
      const key = queue.pop() as string;
      const tiles = lattice.get(key);
      if (tiles) cluster.push(...tiles);

      const [col, row] = key.split(",").map(Number);
      for (let dc = -1; dc <= 1; dc += 1) {
        for (let dr = -1; dr <= 1; dr += 1) {
          if (dc === 0 && dr === 0) continue;
          const neighbour = `${col + dc},${row + dr}`;
          if (lattice.has(neighbour) && !visited.has(neighbour)) {
            visited.add(neighbour);
            queue.push(neighbour);
          }
        }
      }
    }

    clusters.push(cluster);
  }

  return clusters;
}

function summariseCluster(
  tiles: HeatTile[],
  aoiMean: number,
  aoiStdDev: number,
): DetectedCluster {
  const values = tiles.map((t) => t.value);
  const meanValue = values.reduce((a, b) => a + b, 0) / values.length;
  const peakValue = Math.max(...values);

  // Weight the centroid by how hot each tile is, so the pin lands on the
  // thermal core rather than the geometric middle of an irregular cluster.
  const weights = values.map((v) => Math.max(0.001, v - aoiMean + aoiStdDev));
  const weightSum = weights.reduce((a, b) => a + b, 0);
  const center: LatLng = {
    lat: tiles.reduce((acc, t, i) => acc + t.center.lat * weights[i], 0) / weightSum,
    lng: tiles.reduce((acc, t, i) => acc + t.center.lng * weights[i], 0) / weightSum,
  };

  const boxes = tiles.map((t) => (t.ring.length >= 4 ? ringBox(t.ring) : null));
  const validBoxes = boxes.filter((b): b is BoundingBox => b !== null);
  const bbox: BoundingBox = validBoxes.length
    ? validBoxes.reduce((acc, b) => ({
        west: Math.min(acc.west, b.west),
        south: Math.min(acc.south, b.south),
        east: Math.max(acc.east, b.east),
        north: Math.max(acc.north, b.north),
      }))
    : {
        west: center.lng - 0.001,
        south: center.lat - 0.001,
        east: center.lng + 0.001,
        north: center.lat + 0.001,
      };

  return {
    tiles,
    center,
    bbox,
    polygon: tiles.filter((t) => t.ring.length >= 4).map((t) => t.ring),
    meanValue: Math.round(meanValue * 100) / 100,
    peakValue: Math.round(peakValue * 100) / 100,
    anomaly: Math.round((meanValue - aoiMean) * 100) / 100,
    zScore: Math.round(((meanValue - aoiMean) / aoiStdDev) * 100) / 100,
    areaSqMeters: Math.round(tiles.reduce((acc, t) => acc + tileAreaSqMeters(t), 0)),
  };
}

export interface DetectionOutcome {
  clusters: DetectedCluster[];
  /** The z threshold that actually produced the result. */
  zThresholdUsed: number;
  /** Explains an empty result in language the UI can show directly. */
  note?: string;
}

export function detectHotspots(grid: HeatGrid, limit: number): DetectionOutcome {
  if (grid.tiles.length < 12) {
    return {
      clusters: [],
      zThresholdUsed: Z_LADDER[0],
      note: "Not enough temperature tiles were returned for this area to detect hotspots reliably. Try a larger area or a finer granularity.",
    };
  }

  const { mean, stdDev } = grid.stats;

  if (stdDev < MIN_MEANINGFUL_STDDEV_C) {
    return {
      clusters: [],
      zThresholdUsed: Z_LADDER[0],
      note: `Temperature across this area is nearly uniform (spread of ${stdDev.toFixed(2)} °C), so no area stands out as a distinct hotspot.`,
    };
  }

  const geometry = estimateCellGeometry(grid.tiles);
  const maxClusterTiles = Math.max(MIN_CLUSTER_TILES * 3, grid.tiles.length * MAX_CLUSTER_SHARE);

  const clusterAt = (tiles: HeatTile[], z: number): HeatTile[][] => {
    const cutoff = mean + z * stdDev;
    const flagged = tiles.filter((t) => t.value >= cutoff);
    return clusterTiles(flagged, geometry).filter((c) => c.length >= MIN_CLUSTER_TILES);
  };

  /**
   * Hierarchical split: start at the lowest z, then recursively re-cluster any
   * blob that is too large to be an intervention unit, using a stricter
   * threshold on *that blob's tiles only*. Small clusters at the original
   * threshold are kept, so a 6-tile secondary hotspot is not discarded just
   * because a 70-hectare downtown core needed further splitting.
   */
  let deepestZ: number = Z_LADDER[0];

  const splitOversized = (tiles: HeatTile[], zIndex: number): HeatTile[][] => {
    if (tiles.length <= maxClusterTiles || zIndex >= Z_LADDER.length - 1) {
      return [tiles];
    }
    const nextZ = Z_LADDER[zIndex + 1];
    const next = clusterAt(tiles, nextZ);
    if (next.length === 0) return [tiles];
    deepestZ = Math.max(deepestZ, nextZ);
    return next.flatMap((part) => splitOversized(part, zIndex + 1));
  };

  let zUsed: number = Z_LADDER[0];
  let clusters = clusterAt(grid.tiles, zUsed).flatMap((c) => splitOversized(c, 0));
  zUsed = deepestZ;

  if (clusters.length === 0) {
    zUsed = FALLBACK_Z;
    clusters = clusterAt(grid.tiles, FALLBACK_Z);
  }

  if (clusters.length === 0) {
    return {
      clusters: [],
      zThresholdUsed: zUsed,
      note: "Hot tiles in this area are scattered rather than clustered, so there is no contiguous hotspot large enough to act on.",
    };
  }

  const summarised = clusters
    .map((tiles) => summariseCluster(tiles, mean, stdDev))
    // Rank on total thermal load — a large warm zone matters more to a city
    // than a tiny extremely hot one, but intensity should still dominate.
    .sort((a, b) => b.meanValue * Math.sqrt(b.tiles.length) - a.meanValue * Math.sqrt(a.tiles.length))
    .slice(0, limit);

  return { clusters: summarised, zThresholdUsed: zUsed };
}

/**
 * Cool-zone detection: the inverse of a hotspot.
 *
 * Cells significantly *below* the area mean are clustered the same way so the
 * UI can name the parks, water and canopy that are already doing the work.
 */
export function detectCoolZones(grid: HeatGrid, limit: number): DetectionOutcome {
  if (grid.tiles.length < 12) {
    return { clusters: [], zThresholdUsed: Z_LADDER[0] };
  }

  const { mean, stdDev } = grid.stats;
  if (stdDev < MIN_MEANINGFUL_STDDEV_C) {
    return { clusters: [], zThresholdUsed: Z_LADDER[0] };
  }

  const geometry = estimateCellGeometry(grid.tiles);
  const clusterAt = (z: number): HeatTile[][] => {
    const cutoff = mean - z * stdDev;
    const flagged = grid.tiles.filter((t) => t.value <= cutoff);
    return clusterTiles(flagged, geometry).filter((c) => c.length >= MIN_CLUSTER_TILES);
  };

  let zUsed: number = Z_LADDER[0];
  let clusters = clusterAt(zUsed);
  if (clusters.length === 0) {
    zUsed = FALLBACK_Z;
    clusters = clusterAt(FALLBACK_Z);
  }

  if (clusters.length === 0) {
    return { clusters: [], zThresholdUsed: zUsed };
  }

  const summarised = clusters
    .map((tiles) => summariseCluster(tiles, mean, stdDev))
    .sort(
      (a, b) =>
        Math.abs(a.anomaly) * Math.sqrt(a.tiles.length) -
        Math.abs(b.anomaly) * Math.sqrt(b.tiles.length),
    )
    .reverse()
    .slice(0, limit);

  return { clusters: summarised, zThresholdUsed: zUsed };
}

/** Look up the value of another analytic layer inside a cluster footprint. */
export function sampleLayerWithin(
  grid: HeatGrid | undefined,
  bbox: BoundingBox,
  reducer: "mean" | "max" = "mean",
): number | undefined {
  if (!grid || grid.tiles.length === 0) return undefined;

  const inside = grid.tiles.filter(
    (t) =>
      t.center.lng >= bbox.west &&
      t.center.lng <= bbox.east &&
      t.center.lat >= bbox.south &&
      t.center.lat <= bbox.north,
  );
  if (!inside.length) return undefined;

  const values = inside.map((t) => t.value);
  if (reducer === "max") return Math.round(Math.max(...values) * 10) / 10;
  return Math.round((values.reduce((a, b) => a + b, 0) / values.length) * 10) / 10;
}
