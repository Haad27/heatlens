"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { FlaskConical, Thermometer } from "lucide-react";
import SearchBar from "@/components/dashboard/SearchBar";
import ResultsView, { AnalysisLoading } from "@/components/results/ResultsView";
import { cacheAnalysisLocally } from "@/lib/clientStore";
import type { AnalysisResult, GeocodeResult, LatLng } from "@/lib/types";

interface DashboardProps {
  initialCenter: LatLng | null;
  initialLabel: string | null;
  demoMode: boolean;
  defaultHistoricalDate: string;
}

export default function Dashboard({
  initialCenter,
  initialLabel,
  demoMode,
  defaultHistoricalDate,
}: DashboardProps) {
  const router = useRouter();

  const [center, setCenter] = useState<LatLng | null>(initialCenter);
  const [placeLabel, setPlaceLabel] = useState<string | null>(initialLabel);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingStage, setLoadingStage] = useState<string | null>(null);
  const [error, setError] = useState<{ message: string; hint?: string } | null>(null);
  const [selectedHotspotId, setSelectedHotspotId] = useState<string | null>(null);
  const [selectedRecommendationId, setSelectedRecommendationId] = useState<string | null>(null);

  const requestIdRef = useRef(0);
  const stageTimersRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  const clearStageTimers = useCallback(() => {
    stageTimersRef.current.forEach(clearTimeout);
    stageTimersRef.current = [];
  }, []);

  const startStageNarration = useCallback(() => {
    clearStageTimers();
    const stages: [number, string][] = [
      [0, "Reading the heat field"],
      [4000, "Finding hot and cool zones"],
      [9000, "Sampling vegetation and buildings"],
      [14_000, "Scoring recommendations"],
    ];
    for (const [delay, label] of stages) {
      stageTimersRef.current.push(setTimeout(() => setLoadingStage(label), delay));
    }
  }, [clearStageTimers]);

  const runAnalysis = useCallback(
    async (override?: { center?: LatLng; label?: string }) => {
      const targetCenter = override?.center ?? center;
      if (!targetCenter) return;

      const requestId = requestIdRef.current + 1;
      requestIdRef.current = requestId;

      setLoading(true);
      setError(null);
      setSelectedHotspotId(null);
      setSelectedRecommendationId(null);
      startStageNarration();

      try {
        const response = await fetch("/api/analysis", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            center: targetCenter,
            radiusMeters: 1200,
            mode: "historical",
            date: defaultHistoricalDate,
            time: "15:00",
            granularity: 100,
            thresholdC: 32.2,
            placeLabel: override?.label ?? placeLabel ?? undefined,
          }),
        });

        const body = await response.json();
        if (requestId !== requestIdRef.current) return;

        if (!response.ok) {
          setError({ message: body.error ?? "That analysis failed.", hint: body.hint });
          setAnalysis(null);
          return;
        }

        const result = body as AnalysisResult;
        setAnalysis(result);
        cacheAnalysisLocally(result);
        setSelectedRecommendationId(result.brief?.recommendations[0]?.id ?? null);
      } catch {
        if (requestId !== requestIdRef.current) return;
        setError({
          message: "Could not reach the analysis service.",
          hint: "Check your connection and try again.",
        });
      } finally {
        if (requestId === requestIdRef.current) {
          setLoading(false);
          setLoadingStage(null);
          clearStageTimers();
        }
      }
    },
    [center, clearStageTimers, defaultHistoricalDate, placeLabel, startStageNarration],
  );

  const bootstrapped = useRef(false);
  useEffect(() => {
    if (bootstrapped.current || !initialCenter) return;
    bootstrapped.current = true;
    void runAnalysis({ center: initialCenter, label: initialLabel ?? undefined });
  }, [initialCenter, initialLabel, runAnalysis]);

  useEffect(() => () => clearStageTimers(), [clearStageTimers]);

  const handleSelectPlace = (result: GeocodeResult) => {
    setCenter(result.center);
    setPlaceLabel(result.label);
    void runAnalysis({ center: result.center, label: result.label });
  };

  const handleGenerateReport = () => {
    if (!analysis) return;
    cacheAnalysisLocally(analysis);
    router.push(`/report/${analysis.id}`);
  };

  return (
    <div className="flex min-h-dvh flex-col bg-[#f3f6f8]">
      <header className="z-[1100] flex shrink-0 items-center gap-3 border-b border-ink-200 bg-white px-4 py-2.5">
        <Link href="/" className="flex shrink-0 items-center gap-2">
          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-800">
            <Thermometer className="h-4 w-4 text-emerald-100" />
          </span>
          <span className="hidden text-sm font-semibold tracking-tight text-ink-900 sm:block">
            HeatLens
          </span>
        </Link>

        <SearchBar onSelect={handleSelectPlace} className="max-w-xl flex-1" />

        {demoMode && (
          <span
            className="hidden shrink-0 items-center gap-1.5 rounded-full bg-amber-50 px-2.5 py-1 text-[11px] font-medium text-amber-800 ring-1 ring-inset ring-amber-200 md:flex"
            title="No FortyGuard API key is configured, so temperature data is simulated."
          >
            <FlaskConical className="h-3 w-3" />
            Demo data
          </span>
        )}
      </header>

      {loading && !analysis && (
        <AnalysisLoading stage={loadingStage} label={placeLabel} coords={center} />
      )}

      {error && !analysis && !loading && (
        <div className="mx-auto w-full max-w-lg px-4 py-16 text-center">
          <p className="text-sm font-semibold text-ink-900">{error.message}</p>
          {error.hint && <p className="mt-2 text-sm text-ink-500">{error.hint}</p>}
          <button
            type="button"
            onClick={() => router.push("/")}
            className="mt-5 rounded-lg bg-emerald-700 px-4 py-2 text-sm font-semibold text-white"
          >
            Pick another location
          </button>
        </div>
      )}

      {!center && !loading && !analysis && (
        <div className="mx-auto max-w-sm px-4 py-20 text-center">
          <Thermometer className="mx-auto h-8 w-8 text-ink-300" />
          <p className="mt-3 text-sm font-medium text-ink-700">Search a US location to begin</p>
        </div>
      )}

      {analysis && center && (
        <ResultsView
          analysis={analysis}
          center={center}
          grid={analysis.grid}
          selectedHotspotId={selectedHotspotId}
          onSelectHotspot={setSelectedHotspotId}
          overlayOpacity={0.68}
          onNewAnalysis={() => router.push("/")}
          onDownload={handleGenerateReport}
          selectedRecommendationId={selectedRecommendationId}
          onSelectRecommendation={setSelectedRecommendationId}
          demoMode={demoMode}
        />
      )}
    </div>
  );
}
