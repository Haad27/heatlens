"use client";

import type { ReactNode } from "react";
import dynamic from "next/dynamic";
import { Building2, FlaskConical, Thermometer, TreePine } from "lucide-react";
import DetailedAnalysis from "@/components/results/DetailedAnalysis";
import RecommendationsPanel from "@/components/results/RecommendationsPanel";
import { Skeleton } from "@/components/ui/Primitives";
import type { MapLayerKey } from "@/components/map/MapView";
import type { AnalysisResult, HeatGrid, LatLng } from "@/lib/types";

const MapView = dynamic(() => import("@/components/map/MapView"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full w-full items-center justify-center bg-ink-100">
      <Skeleton className="h-full w-full" />
    </div>
  ),
});

export default function ResultsView({
  analysis,
  center,
  grid,
  selectedHotspotId,
  onSelectHotspot,
  overlayOpacity,
  onNewAnalysis,
  onDownload,
  selectedRecommendationId,
  onSelectRecommendation,
  demoMode,
}: {
  analysis: AnalysisResult;
  center: LatLng;
  grid?: HeatGrid;
  selectedHotspotId: string | null;
  onSelectHotspot: (id: string | null) => void;
  overlayOpacity: number;
  onNewAnalysis: () => void;
  onDownload: () => void;
  selectedRecommendationId: string | null;
  onSelectRecommendation: (id: string) => void;
  demoMode: boolean;
}) {
  const { brief, summary } = analysis;
  const veg = brief.areaMetrics.vegetationCoveragePct || summary.vegetationCoveragePct || 0;
  const built = brief.areaMetrics.buildingDensityPct || summary.buildingDensityPct || 0;

  return (
    <div className="mx-auto w-full max-w-6xl space-y-5 px-4 py-6 sm:px-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-ink-900 sm:text-3xl">
            Analysis Results
          </h1>
          <p className="mt-1 text-sm text-ink-500">{analysis.placeLabel}</p>
        </div>
        <div className="flex items-center gap-2">
          {demoMode && (
            <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2.5 py-1 text-[11px] font-medium text-amber-800 ring-1 ring-inset ring-amber-200">
              <FlaskConical className="h-3 w-3" />
              Demo data
            </span>
          )}
          <button
            type="button"
            onClick={onNewAnalysis}
            className="rounded-lg bg-sky-600 px-3.5 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-sky-700"
          >
            New Analysis
          </button>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <MetricCard
          icon={<TreePine className="h-4 w-4 text-emerald-600" />}
          title="Vegetation Coverage"
          subtitle="Current green space"
          value={`${veg}%`}
          barClass="bg-emerald-500"
          pct={veg}
        />
        <MetricCard
          icon={<Building2 className="h-4 w-4 text-sky-600" />}
          title="Building Density"
          subtitle="Urban development"
          value={`${built}%`}
          barClass="bg-sky-500"
          pct={built}
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1.15fr)_minmax(20rem,0.85fr)]">
        <section className="overflow-hidden rounded-2xl border border-ink-200 bg-white shadow-sm">
          <div className="flex items-center gap-2 px-4 py-3">
            <Thermometer className="h-4 w-4 text-red-500" />
            <h2 className="text-sm font-semibold text-ink-900">Heat Map Analysis</h2>
          </div>
          <div className="relative h-[22rem] border-t border-ink-100 sm:h-[28rem]">
            <MapView
              center={center}
              bbox={analysis.bbox}
              grid={grid}
              hotspots={analysis.hotspots}
              selectedHotspotId={selectedHotspotId}
              activeLayer={"temperature" as MapLayerKey}
              overlayOpacity={overlayOpacity}
              onSelectHotspot={onSelectHotspot}
              onPickLocation={() => undefined}
              pickMode={false}
              compactLegend
            />
          </div>
        </section>

        <RecommendationsPanel
          recommendations={brief.recommendations}
          selectedId={selectedRecommendationId}
          onSelect={onSelectRecommendation}
          onDownload={onDownload}
        />
      </div>

      <DetailedAnalysis
        brief={brief}
        onSelectHotspot={onSelectHotspot}
        selectedHotspotId={selectedHotspotId}
      />
    </div>
  );
}

function MetricCard({
  icon,
  title,
  subtitle,
  value,
  barClass,
  pct,
}: {
  icon: ReactNode;
  title: string;
  subtitle: string;
  value: string;
  barClass: string;
  pct: number;
}) {
  return (
    <div className="rounded-2xl border border-ink-200 bg-white p-4 shadow-sm">
      <div className="flex items-center gap-2">
        {icon}
        <div>
          <p className="text-sm font-semibold text-ink-900">{title}</p>
          <p className="text-xs text-ink-400">{subtitle}</p>
        </div>
      </div>
      <p className="mt-3 text-3xl font-semibold tracking-tight text-ink-900 tnum">{value}</p>
      <div className="mt-2 h-2 overflow-hidden rounded-full bg-ink-100">
        <div className={`h-full rounded-full ${barClass}`} style={{ width: `${Math.min(100, pct)}%` }} />
      </div>
    </div>
  );
}

export function AnalysisLoading({
  stage,
  label,
  coords,
}: {
  stage: string | null;
  label: string | null;
  coords: LatLng | null;
}) {
  const steps = [
    "Satellite heat data",
    "Land-cover sampling",
    "Insight synthesis",
  ];

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-1 items-center px-4 py-10">
      <div className="w-full rounded-2xl border border-ink-200 bg-white p-6 shadow-sm">
        <h2 className="text-lg font-semibold text-ink-900">Location Analysis</h2>
        {coords && (
          <p className="mt-2 text-sm text-ink-500 tnum">
            {label ?? "Selected location"} · {coords.lat.toFixed(6)}, {coords.lng.toFixed(6)}
          </p>
        )}
        <p className="mt-5 text-xs font-semibold uppercase tracking-wide text-ink-400">
          Analysis pipeline
        </p>
        <ol className="mt-3 space-y-2">
          {steps.map((step, index) => (
            <li key={step} className="flex items-center gap-2 text-sm text-ink-700">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-600" />
              {step}
              {index === 0 && stage ? (
                <span className="text-xs text-ink-400">— {stage}</span>
              ) : null}
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}
